<?php
/**
 * Joomla Update Server Manifest Generator
 * 
 * Generates dynamic update manifest XML from GitHub releases.
 * Usage: https://www.nospace.net/update-jed/nsprism.php
 */

if (!defined('_JEXEC')) {
    define('_JEXEC', 1);
}

require_once __DIR__ . '/src/JedHelper.php';

use UpdateJed\JedHelper;

// ============================================================================
// CONFIGURATION
// ============================================================================

const GITHUB_REPOSITORY = 'https://github.com/msbragi/joomla-dev';
const GITHUB_API_URL = 'https://api.github.com/repos/msbragi/joomla-dev';
const GITHUB_TOKEN = ''; // Optional: GitHub personal access token

// Extension configuration for nsprism
$extensionConfig = [
    'extension'           => 'nsprism',
    'extension_name'      => 'Nsprism - Prism Code Highlighter',
    'extension_element'   => 'nsprism',
    'extension_type'      => 'plugin',
    'extension_folder'    => 'system',
    'extension_client'    => 'site',
    'maintainer'          => 'nospace.net',
    'maintainer_url'      => 'https://www.nospace.net',
    'github_repo_url'     => GITHUB_REPOSITORY,
    'tag_format'          => '/^nsprism-v([\d.]+)$/',
    'asset_filter'        => 'plg_system_nsprism_v*.zip',
];

// ============================================================================
// HEADER & ROUTING
// ============================================================================

// Build GitHub API URL dynamically
$extensionConfig['github_api_url'] = GITHUB_API_URL;

// Build GitHub API headers
$githubHeaders = [
    'Accept: application/vnd.github.v3+json',
    'User-Agent: Joomla-Extension-Update-Server/1.0',
];
if (GITHUB_TOKEN) {
    $githubHeaders[] = 'Authorization: token ' . GITHUB_TOKEN;
}
$extensionConfig['github_headers'] = $githubHeaders;

// Build changelog URL (autodetects http/https)
$currentProtocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$currentHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$extensionConfig['changelog_url'] = $currentProtocol . '://' . $currentHost . '/update-jed/changelog.php?ext=nsprism';

// ============================================================================
// GENERATE MANIFEST
// ============================================================================

try {
    $helper = new JedHelper($extensionConfig);
    header('Content-Type: application/xml; charset=utf-8');
    echo $helper->buildManifest();
} catch (Exception $e) {
    http_response_code(500);
    echo '<?xml version="1.0"?><error>' . htmlspecialchars($e->getMessage()) . '</error>';
}
?>

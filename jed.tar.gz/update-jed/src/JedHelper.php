<?php
/**
 * Joomla Extension Distribution Helper
 * 
 * Professional class for generating update manifests and changelogs
 * from GitHub releases for Joomla extension submission.
 */

namespace UpdateJed;

class JedHelper
{
    /**
     * Configuration array
     * 
     * @var array
     */
    private $options = [];
    
    /**
     * GitHub releases cache
     * 
     * @var array
     */
    private $releases = [];
    
    /**
     * Filtered and validated updates
     * 
     * @var array
     */
    private $updates = [];
    
    /**
     * Constructor
     * 
     * @param array $options Configuration options:
     *   - extension: Extension identifier (required)
     *   - github_api_url: GitHub API URL
     *   - github_headers: HTTP headers for GitHub API
     *   - tag_format: Regex pattern to extract version from tag
     *   - asset_filter: Asset filename filter pattern
     *   - extension_name: Display name for the extension
     *   - extension_element: Joomla element name
     *   - extension_type: Plugin/component/module etc
     *   - extension_folder: Plugin folder (system/content/etc)
     *   - github_repo_url: GitHub repository URL
     */
    public function __construct(array $options = [])
    {
        $this->options = array_merge($this->getDefaultOptions(), $options);
    }
    
    /**
     * Get default configuration
     * 
     * @return array
     */
    private function getDefaultOptions()
    {
        return [
            'extension'           => '',
            'extension_name'      => '',
            'extension_element'   => '',
            'extension_type'      => 'plugin',
            'extension_folder'    => 'system',
            'extension_client'    => 'site',
            'github_api_url'      => '',
            'github_repo_url'     => '',
            'github_headers'      => [],
            'tag_format'          => '/^v([\d.]+)$/',
            'asset_filter'        => '*.zip',
            'maintainer'          => 'nospace.net',
            'maintainer_url'      => 'https://www.nospace.net',
            'changelog_url'       => '',
        ];
    }
    
    /**
     * Fetch and process releases from GitHub
     * 
     * @return bool True on success
     */
    private function fetchAndProcessReleases()
    {
        if (empty($this->options['github_api_url'])) {
            throw new \Exception('GitHub API URL not configured');
        }
        
        // Fetch releases
        $this->releases = $this->fetchGitHubReleases();
        if (!is_array($this->releases)) {
            return false;
        }
        
        // Process releases
        $this->updates = [];
        foreach ($this->releases as $release) {
            if ($release['draft'] || $release['prerelease']) {
                continue;
            }
            
            $version = $this->extractVersion($release['tag_name']);
            if (!$version) {
                continue;
            }
            
            $downloadUrl = $this->findAsset($release['assets']);
            if (!$downloadUrl) {
                continue;
            }
            
            $this->updates[] = [
                'version'       => $version,
                'versionInt'    => $this->versionToInt($version),
                'tag'           => $release['tag_name'],
                'downloadUrl'   => $downloadUrl,
                'checksum'      => $this->calculateChecksum($downloadUrl),
                'releaseDate'   => $release['published_at'],
                'description'   => $release['body'] ?: 'Release ' . $release['tag_name'],
            ];
        }
        
        // Sort by version (descending)
        usort($this->updates, function($a, $b) {
            return $b['versionInt'] - $a['versionInt'];
        });
        
        return true;
    }
    
    /**
     * Fetch releases from GitHub API
     * 
     * @return array|null
     */
    private function fetchGitHubReleases()
    {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'header'  => implode("\r\n", $this->options['github_headers']),
                'timeout' => 10,
            ],
        ]);
        
        $response = @file_get_contents(
            $this->options['github_api_url'] . '/releases',
            false,
            $context
        );
        
        if ($response === false) {
            return null;
        }
        
        return json_decode($response, true);
    }
    
    /**
     * Extract version from tag using configured regex
     * 
     * @param string $tag Git tag
     * @return string|null
     */
    private function extractVersion($tag)
    {
        if (preg_match($this->options['tag_format'], $tag, $matches)) {
            return $matches[1];
        }
        return null;
    }
    
    /**
     * Find matching asset (ZIP file)
     * 
     * @param array $assets Assets from GitHub release
     * @return string|null Download URL or null
     */
    private function findAsset(array $assets)
    {
        $pattern = str_replace(
            ['\\*'],
            ['[\\d.\\w-]+'],
            preg_quote($this->options['asset_filter'], '/')
        );
        $pattern = '/^' . $pattern . '$/i';
        
        foreach ($assets as $asset) {
            if (preg_match($pattern, $asset['name'])) {
                return $asset['browser_download_url'];
            }
        }
        
        return null;
    }
    
    /**
     * Convert semantic version to comparable integer
     * 
     * @param string $version
     * @return int
     */
    private function versionToInt($version)
    {
        $parts = explode('.', $version);
        $result = 0;
        foreach ($parts as $i => $part) {
            if ($i < 3) {
                $result += (int)$part * pow(1000, 2 - $i);
            }
        }
        return $result;
    }
    
    /**
     * Calculate SHA256 checksum of remote file
     * 
     * @param string $url File URL
     * @return string|null
     */
    private function calculateChecksum($url)
    {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 30,
            ],
            'https' => [
                'method'  => 'GET',
                'timeout' => 30,
            ],
        ]);
        
        $data = @file_get_contents($url, false, $context);
        
        if ($data === false) {
            return null;
        }
        
        return hash('sha256', $data);
    }
    
    /**
     * Parse markdown release notes to plain text
     * 
     * @param string $markdown
     * @param int $maxLines
     * @return array
     */
    private function parseReleaseNotes($markdown, $maxLines = 10)
    {
        if (!$markdown) {
            return [];
        }
        
        $text = $markdown;
        $text = preg_replace('/\[([^\]]+)\]\([^\)]+\)/', '$1', $text);
        $text = preg_replace('/^#+\s+/m', '', $text);
        $text = preg_replace('/\*\*([^\*]+)\*\*/', '$1', $text);
        $text = preg_replace('/\*([^\*]+)\*/', '$1', $text);
        
        $lines = array_filter(array_map('trim', explode("\n", $text)));
        return array_slice($lines, 0, $maxLines);
    }
    
    /**
     * Build Joomla update manifest XML
     * 
     * @return string XML
     * @throws \Exception
     */
    public function buildManifest()
    {
        if (!$this->fetchAndProcessReleases()) {
            throw new \Exception('Failed to fetch releases from GitHub');
        }
        
        $manifest = '<?xml version="1.0" encoding="utf-8"?>' . PHP_EOL;
        $manifest .= '<updates>' . PHP_EOL;
        
        foreach ($this->updates as $update) {
            $manifest .= $this->buildUpdateRow($update);
        }
        
        $manifest .= '</updates>' . PHP_EOL;
        
        return $manifest;
    }
    
    /**
     * Build single update row XML
     * 
     * @param array $update Update data
     * @return string XML
     */
    private function buildUpdateRow(array $update)
    {
        $xml = '    <update>' . PHP_EOL;
        $xml .= '        <name>' . htmlspecialchars($this->options['extension_name']) . '</name>' . PHP_EOL;
        $xml .= '        <description>' . htmlspecialchars(substr($update['description'], 0, 200)) . '</description>' . PHP_EOL;
        $xml .= '        <element>' . htmlspecialchars($this->options['extension_element']) . '</element>' . PHP_EOL;
        $xml .= '        <type>' . htmlspecialchars($this->options['extension_type']) . '</type>' . PHP_EOL;
        $xml .= '        <folder>' . htmlspecialchars($this->options['extension_folder']) . '</folder>' . PHP_EOL;
        $xml .= '        <client>' . htmlspecialchars($this->options['extension_client']) . '</client>' . PHP_EOL;
        $xml .= '        <version>' . htmlspecialchars($update['version']) . '</version>' . PHP_EOL;
        
        if (!empty($this->options['github_repo_url'])) {
            $xml .= '        <infourl title="GitHub">' . htmlspecialchars(
                $this->options['github_repo_url'] . '/releases/tag/' . $update['tag']
            ) . '</infourl>' . PHP_EOL;
        }
        
        if (!empty($this->options['changelog_url'])) {
            $xml .= '        <changelogurl>' . htmlspecialchars($this->options['changelog_url']) . '</changelogurl>' . PHP_EOL;
        }
        
        $xml .= '        <downloads>' . PHP_EOL;
        if ($update['checksum']) {
            $xml .= '            <downloadurl type="full" format="zip" sha256="' . htmlspecialchars($update['checksum']) . '">'
                . htmlspecialchars($update['downloadUrl']) . '</downloadurl>' . PHP_EOL;
        } else {
            $xml .= '            <downloadurl type="full" format="zip">'
                . htmlspecialchars($update['downloadUrl']) . '</downloadurl>' . PHP_EOL;
        }
        $xml .= '        </downloads>' . PHP_EOL;
        
        $xml .= '        <tags>' . PHP_EOL;
        $xml .= '            <tag>stable</tag>' . PHP_EOL;
        $xml .= '        </tags>' . PHP_EOL;
        
        $xml .= '        <maintainer>' . htmlspecialchars($this->options['maintainer']) . '</maintainer>' . PHP_EOL;
        $xml .= '        <maintainerurl>' . htmlspecialchars($this->options['maintainer_url']) . '</maintainerurl>' . PHP_EOL;
        
        $xml .= '        <targetplatform name="joomla" version="4.*"/>' . PHP_EOL;
        $xml .= '        <targetplatform name="joomla" version="5.*"/>' . PHP_EOL;
        $xml .= '        <targetplatform name="joomla" version="6.*"/>' . PHP_EOL;
        
        $xml .= '    </update>' . PHP_EOL;
        
        return $xml;
    }
    
    /**
     * Build changelog XML
     * 
     * @return string XML
     * @throws \Exception
     */
    public function buildChangelog()
    {
        if (empty($this->updates)) {
            if (!$this->fetchAndProcessReleases()) {
                throw new \Exception('Failed to fetch releases from GitHub');
            }
        }
        
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
        $xml .= '<changelogs>' . PHP_EOL;
        
        foreach ($this->updates as $update) {
            $xml .= '    <changelog>' . PHP_EOL;
            $xml .= '        <version>' . htmlspecialchars($update['version']) . '</version>' . PHP_EOL;
            
            $lines = $this->parseReleaseNotes($update['description']);
            
            if (!empty($lines)) {
                $xml .= '        <fix>' . PHP_EOL;
                foreach ($lines as $line) {
                    if (!empty($line)) {
                        $xml .= '            <item>' . htmlspecialchars($line) . '</item>' . PHP_EOL;
                    }
                }
                $xml .= '        </fix>' . PHP_EOL;
            }
            
            $xml .= '    </changelog>' . PHP_EOL;
        }
        
        $xml .= '</changelogs>' . PHP_EOL;
        
        return $xml;
    }
}

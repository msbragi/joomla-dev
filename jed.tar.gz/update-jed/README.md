# JED Update Server System

Professional Joomla Extension Distribution (JED) update system with dynamic manifest and changelog generation from GitHub releases.

## Architecture

### Core Components

- **`config.php`** - Centralized configuration for all extensions
- **`src/JedHelper.php`** - Main class for manifest and changelog generation
- **`nsprism.php`** - Manifest generator for nsprism extension
- **`changelog.php`** - Generic changelog generator (parametric)

### Features

✅ **Dynamic generation** from GitHub releases  
✅ **SHA256 checksums** for file integrity validation  
✅ **XML changelog** with release notes parsing  
✅ **Multi-version support** (Joomla 4, 5, 6)  
✅ **Professional OOP design** with `JedHelper` class  
✅ **Extensible architecture** for adding new extensions  

## Configuration

Edit `config.php` to add new extensions:

```php
const EXTENSION_ASSET_FILTERS = [
    'nsprism' => [
        'filter'      => 'plg_system_nsprism_v*.zip',
        'tag_format'  => '/^nsprism-v([\d.]+)$/',
    ],
    'mycomponent' => [
        'filter'      => 'plg_system_mycomponent_v*.zip',
        'tag_format'  => '/^mycomponent-v([\d.]+)$/',
    ],
];
```

## Creating Update Server for New Extension

### Step 1: Add configuration in `config.php`

```php
'mycomponent' => [
    'filter'      => 'plg_system_mycomponent_v*.zip',
    'tag_format'  => '/^mycomponent-v([\d.]+)$/',
],
```

### Step 2: Create manifest generator (`mycomponent.php`)

```php
<?php
if (!defined('_JEXEC')) define('_JEXEC', 1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/src/JedHelper.php';

use UpdateJed\JedHelper;

$extension = 'mycomponent';
$config = getAssetFilterConfig($extension);

if (!$config) {
    http_response_code(404);
    die('Not configured');
}

$currentProtocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$currentHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
$changelogUrl = $currentProtocol . '://' . $currentHost . '/update-jed/changelog.php?extension=' . urlencode($extension);

$helper = new JedHelper([
    'extension'           => $extension,
    'extension_name'      => 'My Component',
    'extension_element'   => 'mycomponent',
    'extension_type'      => 'component',  // or 'plugin', 'module'
    'extension_folder'    => '',           // leave empty for components
    'github_api_url'      => GITHUB_API_URL,
    'github_repo_url'     => GITHUB_REPOSITORY,
    'github_headers'      => getGitHubHeaders(),
    'tag_format'          => $config['tag_format'],
    'asset_filter'        => $config['filter'],
    'changelog_url'       => $changelogUrl,
]);

try {
    header('Content-Type: application/xml; charset=utf-8');
    echo $helper->buildManifest();
} catch (Exception $e) {
    http_response_code(500);
    echo '<?xml version="1.0"?><error>' . htmlspecialchars($e->getMessage()) . '</error>';
}
?>
```

### Step 3: Update extension manifest

In your component's `mycomponent.xml`:

```xml
<updateservers>
    <server type="extension" name="My Component Update Site" priority="1">
        https://www.nospace.net/update-jed/mycomponent.php
    </server>
</updateservers>
```

## GitHub Setup

### Tag Format

Tags must follow the configured format. For nsprism:

```
nsprism-v1.0.0
nsprism-v1.0.1
nsprism-v1.1.0
```

### Asset Requirements

Each release must include a ZIP file matching the configured pattern (case-insensitive):

```
plg_system_nsprism_v1.0.0.zip
plg_system_nsprism_v1.0.1.zip
```

### Release Notes

Release notes are automatically converted from markdown to plain text for changelog display:

- Links: `[text](url)` → `text`
- Headers: `# Header` removed
- Bold: `**text**` → `text`
- Italic: `*text*` → `text`

## API Endpoints

### Manifest Generator

**Development:**
```
http://www.nospace.lan/update-jed/nsprism.php
```

**Production:**
```
https://www.nospace.net/update-jed/nsprism.php
```

Returns Joomla-compatible update XML with:
- Latest releases (excludes drafts and pre-releases)
- SHA256 checksums for validation
- Multi-platform targeting (Joomla 4, 5, 6)
- GitHub release links

### Changelog Generator

```
http://www.nospace.lan/update-jed/changelog.php?extension=nsprism
```

Returns XML changelog compatible with Joomla's update manager popup.

## JedHelper Class Reference

### Constructor

```php
$helper = new JedHelper([
    'extension'           => 'nsprism',
    'extension_name'      => 'Display Name',
    'extension_element'   => 'nsprism',
    'extension_type'      => 'plugin',
    'extension_folder'    => 'system',
    'extension_client'    => 'site',
    'github_api_url'      => 'https://api.github.com/repos/owner/repo',
    'github_repo_url'     => 'https://github.com/owner/repo',
    'github_headers'      => [],
    'tag_format'          => '/^nsprism-v([\d.]+)$/',
    'asset_filter'        => 'plg_system_nsprism_v*.zip',
    'changelog_url'       => 'http:///.../changelog.php?extension=nsprism',
]);
```

### Methods

#### `buildManifest(): string`

Returns Joomla-compatible update manifest XML.

```php
header('Content-Type: application/xml; charset=utf-8');
echo $helper->buildManifest();
```

#### `buildChangelog(): string`

Returns Joomla-compatible changelog XML.

```php
header('Content-Type: application/xml; charset=utf-8');
echo $helper->buildChangelog();
```

## Environment Variables

Optional GitHub personal access token in `config.php`:

```php
const GITHUB_TOKEN = 'ghp_xxxxxxxxxxxx';
```

[Get a token](https://github.com/settings/tokens)  
Scopes needed: `public_repo`

Benefits:
- Higher API rate limits (5,000 requests/hour vs 60)
- Access to private repositories
- More reliable authentication

## Error Handling

All endpoints return proper HTTP status codes:

- `200` - Success
- `400` - Bad request (missing parameters)
- `404` - Extension not found
- `500` - Server error
- `503` - GitHub API unreachable

Errors return XML with error element:

```xml
<?xml version="1.0"?>
<error>Failed to fetch releases from GitHub</error>
```

## JED Submission Requirements

Before submitting to JED, ensure:

✅ Update server URL uses `https` (production domain)  
✅ All releases have proper git tags  
✅ ZIP files follow naming convention  
✅ Extension manifest includes `<updateservers>` section  
✅ GitHub API is accessible from JED servers  
✅ At least one stable release published (no drafts/pre-releases)  

## Testing

### Local Testing

```bash
# Test manifest
curl http://www.nospace.lan/update-jed/nsprism.php

# Test changelog
curl "http://www.nospace.lan/update-jed/changelog.php?extension=nsprism"
```

### In Joomla Admin

1. **Extensions → Manage → Discover**
2. **Discover Extensions**
3. Check "Installed Discover" count increased
4. **Extensions → Update Extensions**
5. **Verify Updates** - should show available update
6. Click **Changelog** - should display release notes

## Troubleshooting

### "Extension not configured" error

- Check extension name matches `config.php` mapping
- Verify `tag_format` is valid regex

### Changelog shows only title

- Check `changelogurl` parameter is correct
- Clear Joomla database cache: `DELETE FROM #__updates WHERE element='xxx'`
- Verify changelog.php is accessible

### SHA256 mismatch error

- File not accessible during checksum calculation
- Network timeout during download
- Check file permissions on GitHub

## License

GNU General Public License version 2 or later

<?php
/**
 * Joomla Extension Changelog Generator
 * 
 * Generates changelog XML from GitHub releases.
 * Usage: changelog.php?ext=nsprism
 */

if (!defined('_JEXEC')) {
    define('_JEXEC', 1);
}

require_once __DIR__ . '/src/JedHelper.php';

use UpdateJed\JedHelper;

// ============================================================================
// CONFIGURATION
// ============================================================================

const GITHUB_API_URL = 'https://api.github.com/repos/msbragi/joomla-dev';
const GITHUB_TOKEN = ''; // Optional: GitHub personal access token

// Available extensions
$extensions = [
    'nsprism' => [
        'github_api_url'  => GITHUB_API_URL,
        'tag_format'      => '/^nsprism-v([\d.]+)$/',
        'asset_filter'    => 'plg_system_nsprism_v*.zip',
    ],
    // Add more extensions as needed
];

// ============================================================================
// HANDLER
// ============================================================================

// Get extension identifier from query parameter
$ext = isset($_GET['ext']) ? preg_replace('/[^a-z0-9_-]/i', '', $_GET['ext']) : '';

if (!$ext || !isset($extensions[$ext])) {
    http_response_code(400);
    header('Content-Type: application/xml');
    die('<?xml version="1.0"?><error>Unknown extension</error>');
}

// Build GitHub API headers
$githubHeaders = [
    'Accept: application/vnd.github.v3+json',
    'User-Agent: Joomla-Extension-Update-Server/1.0',
];
if (GITHUB_TOKEN) {
    $githubHeaders[] = 'Authorization: token ' . GITHUB_TOKEN;
}

// Configure changelog helper
$config = $extensions[$ext];
$helper = new JedHelper([
    'extension'       => $ext,
    'github_api_url'  => $config['github_api_url'],
    'github_headers'  => $githubHeaders,
    'tag_format'      => $config['tag_format'],
    'asset_filter'    => $config['asset_filter'],
]);

try {
    header('Content-Type: application/xml; charset=utf-8');
    echo $helper->buildChangelog();
} catch (Exception $e) {
    http_response_code(500);
    echo '<?xml version="1.0"?><error>' . htmlspecialchars($e->getMessage()) . '</error>';
}
?>
